#ifndef __EURONEXT_COMMON_H__
#define __EURONEXT_COMMON_H__
namespace euronext
{
	class EuronextFeedHandler;
	class EuronextLineGroup;
	class EuronextLine;
};
#endif //__EURONEXT_COMMON_H__
