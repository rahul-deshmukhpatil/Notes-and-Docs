#ifndef __OMXNORDIC_COMMON_H__
#define __OMXNORDIC_COMMON_H__
namespace omxnordic
{
	class OMXNordicFeedHandler;
	class OMXNordicLineGroup;
	class OMXNordicLine;
};
#endif //__OMXNORDIC_COMMON_H__
