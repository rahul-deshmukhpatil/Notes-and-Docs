#ifndef __MILLENIUM_COMMON_H__
#define __MILLENIUM_COMMON_H__
namespace millenium
{
	class MilleniumFeedHandler;
	class MilleniumLineGroup;
	class MilleniumLine;
};
#endif //__MILLENIUM_COMMON_H__
