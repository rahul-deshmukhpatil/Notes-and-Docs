#ifndef __PRICELEVELS_H__
#define __PRICELEVELS_H__

namespace core
{
	class PriceLevels
	{
	};
}

#endif //__PRICELEVELS_H__
