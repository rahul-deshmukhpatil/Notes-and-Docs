#ifndef __PRICELEVELS_H__
#define __PRICELEVELS_H__

namespace base 
{
	class PriceLevels
	{
	};
}

#endif //__PRICELEVELS_H__
