#ifndef __CUSTOM_H__
#define __CUSTOM_H__

namespace base
{
	class Custom
	{
	};
}

#endif //__CUSTOM_H__
